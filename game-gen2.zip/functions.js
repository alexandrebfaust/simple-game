/*
Up - 38
Down - 40
Left - 37
Right - 39
*/
/*SEMPRE TRABALHAR COM MÚLTIPLOS DE 2*/
var posicaomapa = 0;
var posicaoplataforma = 0;
var posicaomapamin = 120;
var posicaomapamax = -3000;
var posicaoplataformamin = 600;
var posicaoplataformamax = -15000;
var posicaopersonagem = 0;
var tamanhopersonagem = 80;
var margempersonagem = 100;
var xpersonagem = tamanhopersonagem+margempersonagem;
var acaopersonagem = 'idle';
var direcaopersonagem = 'direita';
var moedas = 0;
var chaveouro = 0;
var chaveprata = 0;
var posicaobarreira = 0;



/*BARREIRAS*/
function localizarbarreira(){
	if($(".barrier")){
		posicaobarreira = $(".barrier").css("left");
		console.log(posicaobarreira);
		posicaobarreira = posicaobarreira.replace("px", "");
		posicaobarreira = (posicaobarreira*(-1)+120);
	}
}

localizarbarreira();

/*ABRIR BARREIRA*/
$(".barrier").click(function() {
	if(moedas >= 1){
		console.log('abriu');
		$(this).remove();
		moedas -= 1;
		$("#coins").html(moedas);
		localizarbarreira();
  }
});

/*PEGAR MOEDA*/
$(".item").click(function() {
console.log('pegou');
  $(this).css('display', 'none');
  moedas += 1;
  $("#coins").html(moedas);
});

/*PEGAR CHAVE OURO*/
$(".keyg").click(function() {
	//console.log('pegou');
  $(this).css('display', 'none');
  chaveouro += 1;
  $("#keysg").html(chaveouro);
});

/*PEGAR CHAVE PRATA*/
$(".keys").click(function() {
	//console.log('pegou');
  $(this).css('display', 'none');
  chaveprata += 1;
  $("#keyss").html(chaveprata);
});

function movermapaesquerda(){
	if (posicaoplataformamin != posicaoplataforma){
		posicaomapa += 2;
		posicaoplataforma += 10;
		$('.map').css('background-position-x', posicaomapa);
		$('.platform').css('background-position-x', posicaoplataforma);
		$('.texts').css('left', posicaoplataforma);
		$('.items').css('left', posicaoplataforma);
	}
	else{
		console.log('Voce nao pode mover para Esquerda');
	}
}

function movermapadireita(){
	if (posicaoplataformamax != posicaoplataforma){
		if(posicaoplataforma != posicaobarreira){
			posicaomapa -= 2;
			posicaoplataforma -= 10;
			$('.map').css('background-position-x', posicaomapa);
			$('.platform').css('background-position-x', posicaoplataforma);
			$('.texts').css('left', posicaoplataforma);
			$('.items').css('left', posicaoplataforma);
		}
	}
	else{
		console.log('Voce nao pode mover para Direita');
	}
}

function moverpersonagemesquerda(){
	$('#char').css('transform', 'scaleX(-1)');
	direcaopersonagem = 'esquerda';
	if(acaopersonagem == 'idle'){
		acaopersonagem = 'run';
		$("#char").attr("src","src/PNG/run.gif");
	}
}

function moverpersonagemdireita(){
	$('#char').css('transform', 'scaleX(1)');
	direcaopersonagem = 'direita';
	if(acaopersonagem == 'idle'){
		acaopersonagem = 'run';
		$("#char").attr("src","src/PNG/run.gif");
	}
	console.log('posicao: '+posicaoplataforma);
	console.log('BARREIRA: '+posicaobarreira);
}

function personagematacar(){
	$("#char").attr("src","src/PNG/grab.gif");
}


/*CORRENDO SETAS*/
$(document).keydown(function(e) {
	if((e.keyCode || e.which) == 37) { //Esquerda
    	//console.log('Esquerda');
    	movermapaesquerda();
    	moverpersonagemesquerda();
    }
    if((e.keyCode || e.which) == 39) { //Direita
    	//console.log('Direita');
    	movermapadireita();
    	moverpersonagemdireita();
    }
    if((e.keyCode || e.which) == 88) { //Direita
    	console.log('Atacar');
    	personagematacar();
    }
});

/*CORRENDO BOTAO*/
$("#btnesquerda").click(function() {
	console.log('Esquerda');
    	movermapaesquerda();
    	moverpersonagemesquerda();
});
$("#btndireita").click(function() {
	console.log('Direita');
    	movermapadireita();
    	moverpersonagemdireita();
});

/*PARADO*/
$(document).keyup(function(e){
	if(acaopersonagem == 'run'){
		acaopersonagem = 'idle';
		$("#char").attr("src","src/PNG/idle.gif");
	}
});